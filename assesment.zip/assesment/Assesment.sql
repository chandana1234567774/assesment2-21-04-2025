----->Question1:
CREATE TABLE students1 (
    id INT  PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    age INT,
    marks DECIMAL(5,2)
);
insert into students1 values(1,'ram','ram@gmail.com',18,90.5);
insert into students1 values(2,'seetha','seetha@gmail.com',20,80.19);
insert into students1 values(3,'ammu','ammu@gmail.com',16,95.7);
insert into students1 values(4,'chandu','chandu@gmail.com',21,82.8);
insert into students1 values(5,'chandana','chandana@gmail.com',22,89.9);
select * from students1;



-- Question2:
SELECT * FROM students1 WHERE age > 21;

-- Question3: 
UPDATE students1
SET email = 'ammuchandu@gmail.com'
WHERE id = 5;

-- Question4: 
DELETE FROM students1 WHERE age < 18;

-- Question5: 
SELECT * FROM students1
ORDER BY marks DESC
LIMIT 1 OFFSET 1;

-- Question6: 
CREATE TABLE courses (
    course_id INT,
    student_id INT,
    course_name VARCHAR(100)
);

INSERT INTO courses (course_id, student_id, course_name) VALUES
(101, 1, 'Java'),
(102, 2, 'Python'),
(103, 1, 'SQL');
select * from courses;

SELECT s.name AS student_name, c.course_name
FROM students1 s
JOIN courses c ON s.id = c.student_id;
